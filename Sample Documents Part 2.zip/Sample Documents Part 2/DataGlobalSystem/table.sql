CREATE TABLE employeeMaster
(employeeId NUMBER(5) PRIMARY KEY,
employeeName VARCHAR2(50),
password VARCHAR2(20),
role VARCHAR2(20));

//to be confirmed
CREATE SEQUENCE sq_trainingCode START WITH 100;

CREATE TABLE trainingProgram(
trainingCode NUMBER(5) PRIMARY KEY,
courseCode NUMBER(5) REFERENCES courseMaster(courseId),
facultyCode NUMBER(5) REFERENCES employeeMaster(employeeId),
startDate DATE,
endDate DATE);

//confirm course id 
CREATE SEQUENCE sq_courseId START WITH 100;

CREATE TABLE courseMaster(
courseId NUMBER(5) PRIMARY KEY,
courseName VARCHAR2(50),
noOfDays NUMBER(5)
);

CREATE TABLE facultySkill(
facultyId NUMBER(5) REFERENCES employeeMaster(employeeId),
skillSet VARCHAR2(200));

CREATE TABLE participantEnrollment(
trainingCode NUMBER(5) REFERENCES trainingProgram(trainingCode),
participantId NUMBER(5) REFERENCES employeeMaster(employeeId));

CREATE TABLE feedbackMaster(
trainingCode number(5) REFERENCES trainingProgram(trainingCode),
participantId number(5) REFERENCES employeeMaster(employeeId),
fbPrsComm NUMBER(1),
fbClrfyDbts NUMBER(1),
fbTm NUMBER(1),
fbHndOut NUMBER(1),
fbHwSwNtwrk NUMBER(1),
comments VARCHAR2(200),
suggestions VARCHAR2(200),sysdate);



INSERT INTO employeeMaster VALUES(1, 'Ruth' , 'part123', 'participant');
INSERT INTO employeeMaster VALUES(2, 'Janisha' , 'coord123', 'coordinator');
INSERT INTO employeeMaster VALUES(3, 'Surabhi' , 'admin123', 'admin');
INSERT INTO employeeMaster VALUES(4, 'Rajeev' , 'rajeev123', 'faculty');
INSERT INTO employeeMaster VALUES(5, 'Shankar' , 'shankar123', 'faculty');
INSERT INTO employeeMaster VALUES(6, 'Suraj' , 'suraj123', 'participant');

INSERT INTO courseMaster VALUES(sq_courseId.nextval, 'Java' , 44);
INSERT INTO courseMaster VALUES(sq_courseId.nextval, 'Oracle' , 60);
INSERT INTO courseMaster VALUES(sq_courseId.nextval, 'Servlet' , 5);
INSERT INTO courseMaster VALUES(sq_courseId.nextval, 'Servlet' , 5);

INSERT INTO facultySkill VALUES(4, 'CoreJava,Oracle,AdvancedJava');
INSERT INTO facultySkill VALUES(5, 'Servlet, WebServices');

INSERT INTO trainingProgram VALUES(sq_trainingCode.nextval,100,4,sysdate, sysdate+44 );
INSERT INTO trainingProgram VALUES(sq_trainingCode.nextval,101,5,sysdate, sysdate+5 );
INSERT INTO trainingProgram VALUES(sq_trainingCode.nextval,120,2,sysdate, sysdate+44 );
INSERT INTO trainingProgram VALUES(sq_trainingCode.nextval,101,3,sysdate, sysdate+20 );
INSERT INTO trainingProgram VALUES(sq_trainingCode.nextval,100,1,sysdate, sysdate+15 );
INSERT INTO trainingProgram VALUES(sq_trainingCode.nextval,120,6,sysdate, sysdate+15 );

INSERT INTO participantEnrollment VALUES(100,1);
INSERT INTO participantEnrollment VALUES(101,6);

INSERT INTO feedbackMaster VALUES(100,1,4,2,3,5,1,'Good','Need to improve');
INSERT INTO feedbackMaster VALUES(101,6,2,4,5,2,4,'Bad','Need to improve');


select * from participantEnrollment;



//Admin table Feedback
SQL> select tp.startdate,cm.coursename,em.employeename,fm.fbPrsComm,fm.fbClrfyDb
ts,fm.fbTm,fm.fbHndOut,fm.fbHwSwNtwrk from Trainingprogram tp join coursemaster
cm on tp.coursecode=cm.courseid join employeemaster em on em.employeeid=tp.facul
tycode join feedbackmaster fm on fm.participantId=em.employeeid;

//view
SQL> create view demo_view as select tp.startdate,cm.coursename,em.employeename,
fm.fbPrsComm,fm.fbClrfyDbts,fm.fbTm,fm.fbHndOut,fm.fbHwSwNtwrk from Trainingprog
ram tp join coursemaster cm on tp.coursecode=cm.courseid join employeemaster em
on em.employeeid=tp.facultycode join feedbackmaster fm on fm.participantId=em.em
ployeeid;
