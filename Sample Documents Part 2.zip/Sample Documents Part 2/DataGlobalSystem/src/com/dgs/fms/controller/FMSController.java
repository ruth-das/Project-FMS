package com.dgs.fms.controller;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dgs.fms.dto.DemoView;
import com.dgs.fms.dto.EmployeeMaster;
import com.dgs.fms.dto.FeedbackMaster;
import com.dgs.fms.exception.FMSException;
import com.dgs.fms.service.FMSServiceImpl;
import com.dgs.fms.service.IFMSService;

/**
 * Servlet implementation class FMSController
 */
// @WebServlet("/SubmitFeedback")
@WebServlet("*.do")
public class FMSController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	IFMSService fmsService;
	EmployeeMaster emp;

	/**
	 * Default constructor.
	 */
	public FMSController() {
		fmsService = new FMSServiceImpl();
		emp = new EmployeeMaster();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest
	 * , javax.servlet.http.HttpServletResponse)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		FeedbackMaster feedback = new FeedbackMaster();
		// response.setContentType("text/html");
		// PrintWriter out=response.getWriter();
		String urlPattern = request.getServletPath();

		switch (urlPattern) {

		case "/SubmitFeedback.do":
			System.out.println("avhg");
			HttpSession session = request.getSession(true);

			int trainingCode = Integer.parseInt(request
					.getParameter("trainingcode"));
			int participantid = Integer.parseInt(request
					.getParameter("participantid"));
			int communicationskills = Integer.parseInt(request
					.getParameter("communicationskills"));
			int clarifydoubts = Integer.parseInt(request
					.getParameter("clarifydoubts"));
			int timemanagement = Integer.parseInt(request
					.getParameter("timemanagement"));
			int handouts = Integer.parseInt(request.getParameter("handouts"));
			int network = Integer.parseInt(request.getParameter("network"));
			String comments = request.getParameter("comments");
			String suggestions = request.getParameter("suggestions");

			try {

				feedback.setTrainingCode(trainingCode);
				feedback.setParticipantId(participantid);
				feedback.setFbPrsComm(communicationskills);
				feedback.setFbClrfyDbts(clarifydoubts);
				feedback.setFbTm(timemanagement);
				feedback.setFbHndOut(handouts);
				feedback.setFbHwSwNtwrk(network);
				feedback.setComments(comments);
				feedback.setSuggestions(suggestions);

				int i = fmsService.insertFeedback(feedback);
			} catch (FMSException e) {

				e.printStackTrace();
			}
			RequestDispatcher dispatch = request
					.getRequestDispatcher("FeedbackSuccess.jsp");
			dispatch.forward(request, response);

			break;

		case "/LoginMatch.do":
			session = request.getSession(true);
			
			
			String employeeName = request.getParameter("txtusername");
			// session.setAttribute("employee", employeeName);
			String url ="";
			String password = request.getParameter("txtpassword");
			String userType = request.getParameter("usertype");
			System.out.println(userType);
			
			if (userType.equals("admin")) {
				url ="AdminHome.jsp";

			} else if (userType.equals("participant")) {
				url= "ParticipantHome.jsp";
			} else if (userType.equals("coordinator")) {
				url = "CoordinatorHome.jsp";
			}
			System.out.println(url);
		
		
			try {
				emp = fmsService.matchLogin(employeeName);
				System.out.println(emp.toString());
				if (employeeName.equals(emp.getEmployeeName()) && password.equals(emp.getPassword()) && userType.equals(emp.getRole())) {
					
					
					dispatch = request.getRequestDispatcher(url);
					dispatch.forward(request, response);
				} else {
					System.out.println("invalid username password");
					dispatch = request.getRequestDispatcher("Login.jsp");
					dispatch.include(request, response);
				}
			} catch (FMSException e) {
				e.printStackTrace();
			}

			break;

		case "/generateMonth.do":
			session = request.getSession(true);
			DemoView dv = new DemoView();
			String month = request.getParameter("month");
			try {
				List<DemoView> NewList = fmsService.showMonthlyFeedback(month);
				session.setAttribute("fbList", NewList);
				System.out.println(NewList);
			} catch (FMSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			dispatch = request.getRequestDispatcher("MonthFeedback.jsp");
			dispatch.forward(request, response);
			break;

		case "/Defaulters.do":
			dispatch = request.getRequestDispatcher("Defaulters.jsp");
			dispatch.forward(request, response);
			break;
		case "/FacultyFeedback.do":
			dispatch = request.getRequestDispatcher("FacultyFeedback.jsp");
			dispatch.forward(request, response);
			break;
		}
	}
}
