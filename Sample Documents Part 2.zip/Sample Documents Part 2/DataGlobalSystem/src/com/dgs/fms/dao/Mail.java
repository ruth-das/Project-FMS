package com.dgs.fms.dao;
import java.security.Security;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class Mail {    
    public static void sendMail(String sendto,String subject,String body){
 			System.out.println(sendto+":"+subject);
    	 	javax.mail.Session session=null;
    	 try {
    		Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
		    final String SSL_FACTORY = "javax.net.ssl.SSLSocketFactory";
		    Properties props = System.getProperties();
		    props.setProperty("mail.smtp.host", "smtp.gmail.com");
		    props.setProperty("mail.smtp.socketFactory.class", SSL_FACTORY);
		    props.setProperty("mail.smtp.socketFactory.fallback", "false");
		    props.setProperty("mail.smtp.port", "465");
		    props.setProperty("mail.smtp.socketFactory.port", "465");
		    props.put("mail.smtp.auth", "true");
		    final String username = "1200hot@gmail.com"; 
		    final String password = "";
		    Session mailsession = Session.getDefaultInstance(props,new Authenticator() {
		       protected PasswordAuthentication getPasswordAuthentication() {
		       return new PasswordAuthentication("1200hot@gmail.com",  "");
		      }
		     });
		    Message msg = new MimeMessage(mailsession);
		    msg.setFrom(new InternetAddress("1200hot@gmail.com"));
            Address address=new InternetAddress(sendto);
            msg.setRecipient(Message.RecipientType.TO, address);
		    msg.setSubject(subject);
   		    msg.setText(body);
   		    
		    msg.setSentDate(new java.util.Date());
		    Transport.send(msg);
			System.out.println("msg send successfully");    		
        }
        catch (Exception ex) {
        	System.out.print(ex.toString());
        }    	
    }
}



