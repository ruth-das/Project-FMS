package com.dgs.fms.dto;

import java.util.Date;

public class DemoView {

	private Date startDate;
	private String courseName;
	private String employeeName;
	private int fbPrsComm;
	private int fbClrfyDbts;
	private int fbTm;
	private int fbHndOut;
	private int fbHwSwNw;
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public int getFbPrsComm() {
		return fbPrsComm;
	}
	public void setFbPrsComm(int fbPrsComm) {
		this.fbPrsComm = fbPrsComm;
	}
	public int getFbClrfyDbts() {
		return fbClrfyDbts;
	}
	public void setFbClrfyDbts(int fbClrfyDbts) {
		this.fbClrfyDbts = fbClrfyDbts;
	}
	public int getFbTm() {
		return fbTm;
	}
	public void setFbTm(int fbTm) {
		this.fbTm = fbTm;
	}
	public int getFbHndOut() {
		return fbHndOut;
	}
	public void setFbHndOut(int fbHndOut) {
		this.fbHndOut = fbHndOut;
	}
	public int getFbHwSwNw() {
		return fbHwSwNw;
	}
	public void setFbHwSwNw(int fbHwSwNw) {
		this.fbHwSwNw = fbHwSwNw;
	}
	@Override
	public String toString() {
		return "DemoView [startDate=" + startDate + ", courseName="
				+ courseName + ", employeeName=" + employeeName
				+ ", fbPrsComm=" + fbPrsComm + ", fbClrfyDbts=" + fbClrfyDbts
				+ ", fbTm=" + fbTm + ", fbHndOut=" + fbHndOut + ", fbHwSwNw="
				+ fbHwSwNw + "]";
	}
	
}
